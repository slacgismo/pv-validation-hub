def predict(test_data):
    # run prediction
    preds = []
    for d in test_data:
        preds.append(d)
    return preds
