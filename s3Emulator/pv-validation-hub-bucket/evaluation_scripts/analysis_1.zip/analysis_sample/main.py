import pandas as pd
import glob
import os
import time


def cal_error(outputs, ground_truth):
    tilt_delta = abs(outputs[0] - ground_truth[0])
    az_delta = abs(outputs[1] - ground_truth[1])
    error = (tilt_delta + az_delta) / 2
    return error


def evaluate(base_dir, predict_modules):
    # Read in all of the data sets and the associated metadata
    data_files = glob.glob(os.path.join(base_dir, "data/*.csv"))
    # Drop the metadata file
    data_files = [x for x in data_files if 'metadata.csv' not in x]
    # print(data_files)

    # Get the metadata file
    metadata_df = pd.read_csv(os.path.join(base_dir, "data/metadata.csv"))

    # Get a list of the modules that we're going to be testing. Ideally, this would be housed in some sort of database
    # modules_to_import = ["az-tilt-estimator"]
    # note: the modules should have been loaded in the worker, just use predict_modules

    # Generate a list to store all of the results as associated dictionary values
    results_list = list()
    errors = []
    execution_times = []
    details = {}

    # Loop through each file, get its associated metadata, and run it through the function
    for file in data_files:
        file_name = file.split("/")[-1]
        df = pd.read_csv(file, index_col=0, parse_dates=True)
        # Get the metadata associated with the specific file
        associated_metadata = dict(
            metadata_df[metadata_df['file'] == file_name].iloc[0])
        # print(associated_metadata)
        # Build pandas series for power stream
        time_series = pd.Series(df[associated_metadata['power_stream']])

        for mod in predict_modules:
            function = getattr(mod, "run_az_tilt_estimation")
            start = time.time()
            tilt, az = function(time_series,
                                associated_metadata['latitude'],
                                associated_metadata['longitude'],
                                associated_metadata['time_zone'])
            end = time.time()
            execution_time = end - start
            error = cal_error(
                (tilt, az), (associated_metadata['tilt'], associated_metadata['azimuth']))
            # print(tilt, az)
            results_list.append({"test": "azimuth-tilt estimation",
                                "data": file_name,
                                 "module": mod,
                                 "execution_time": execution_time,
                                 "outputs": (tilt, az),
                                 "ground_truth": (associated_metadata['tilt'], associated_metadata['azimuth'])})

            errors.append(error)
            execution_times.append(execution_time)
            details[file_name] = {"execution_time": execution_time,
                                  "outputs": (tilt, az),
                                  "ground_truth": (associated_metadata['tilt'], associated_metadata['azimuth']),
                                  "error": error}

    # print(results_list)
    total_results = {"mean_error": sum(errors) / len(errors),
                     "total_execution_time": sum(execution_times),
                     "details": details}
    return total_results
