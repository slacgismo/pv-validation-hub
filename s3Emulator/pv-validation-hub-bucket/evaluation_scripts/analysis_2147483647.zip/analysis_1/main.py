import sys
import traceback


def evaluate(test_data_file, test_annotation_file, predict_func, **kwargs):
    # load or synthesize data
    data = []
    with open(test_data_file, "r") as f:
        for line in f:
            data.append(int(line.strip()))
    # can be extended to support multiple test datasets/splits
    test_data = {'split1': data}

    # predict
    print("Predicting ...")
    user_values = {}
    for split, data in test_data.items():
        user_values[split] = predict_func(data)
    user_values = user_values['split1']
    print("Successfully run prediction")

    # load annotations
    original_values = []
    print("Loading Test annotation file ...")
    with open(test_annotation_file, "r") as f:
        for line in f:
            original_values.append(int(line.strip()))
    print("Successfully loaded the test annotation file")

    # evaluate results
    score = set(user_values).intersection(original_values).__len__()
    result = {}
    try:
        result['result'] = [
            {
                'split1': {
                    'score': score,
                }
            }
        ]
        result['submission_metadata'] = "This submission metadata will only be shown to the Challenge Host"
        result['submission_result'] = "This is the actual result to show to the participant once submission is finished"
        return result
    except Exception as e:
        sys.stderr.write(traceback.format_exc())
        return e
