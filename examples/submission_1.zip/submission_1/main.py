def predict(data_file_path, output_file_path):
    # load test data
    data = []
    with open(data_file_path, "r") as f:
        for line in f:
            data.append(int(line.strip()))
    
    # run prediction
    outputs = []
    for d in data:
        outputs.append(d)
    
    # output
    with open(output_file_path, 'w') as f:
        f.write('\n'.join([str(o) for o in outputs]))

