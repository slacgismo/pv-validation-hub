def predict(test_data):
    # run prediction
    outputs = {}
    for split, data in test_data.items():
        preds = []
        for d in data:
            preds.append(d)
        outputs[split] = preds
    return outputs
